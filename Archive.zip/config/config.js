// config/config.js
const dbConfig = require('./db.config');
module.exports = dbConfig;
